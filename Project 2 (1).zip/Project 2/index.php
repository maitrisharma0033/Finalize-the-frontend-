<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">

    <title>Prateek Fitness | Home</title>
    <style>
        .form{
            margin: 10px 0px;
            background-color: black;
            color: ivory;
        }

        .nav-font{
            font-size: 20px;
            color: goldenrod;
        }
        
        .c-font{
            color: darkgoldenrod;
        }
    </style>
</head>

<body style="background-color: black; font-family: cursive; color: white;">
    <nav class="navbar navbar-expand-lg" style="background-color: #c85959; padding: 2px 2px;">
        <div class="container-fluid">
            <div>
            <a class="navbar-brand" href="index.html">
                <img src="logo1.png" height="30px" width="50px" alt="">
            </a>
            </div>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown"
                aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon">≡</span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav ">
                    <li class="nav-item">
                        <a class="nav-link active nav-font" aria-current="page" href="index.html">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link nav-font" href="features.html">Features</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link nav-font" href="pricing.html">Pricing</a>
                    </li>
                    <li class="nav-item dropdown ">
                        <a class="nav-link dropdown-toggle nav-font" href="#" id="navbarDropdownMenuLink" role="button"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            Select Pack
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                            <li><a class="dropdown-item" href="Cardio.html">Cardio</a></li>
                            <li><a class="dropdown-item" href="weight lifting.html">Weight Lifting</a></li>
                            <li><a class="dropdown-item" href="c&w.html">Cardio & Weight Lifting</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div>
        <h2 class="display-3" style="color: white; text-align: center;">Prateek Fitness</h2>
    </div>


    <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel" style="background-color: black;">
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active"
                aria-current="true" aria-label="Slide 1"></button>
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1"
                aria-label="Slide 2"></button>
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2"
                aria-label="Slide 3"></button>
        </div>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="c-img1.jpg" class="d-block w-100" style="width: 100%; height: 700px;" alt="...">
                <div class="carousel-caption d-none d-md-block c-font">
                    <h1 class="display-4">Prateek Fitness</h1>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dignissimos, laudantium!</p>
                </div>
            </div>
            <div class="carousel-item">
                <img src="c-img2.jpg" class="d-block w-100" style="width: 100%; height: 700px;" alt="...">
                <div class="carousel-caption d-none d-md-block c-font">
                    <h1 class="display-4">Prateek Fitness</h1>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Veritatis, corrupti?</p>
                </div>
            </div>
            <div class="carousel-item">
                <img src="c-img3.jpg" class="d-block w-100" style="width: 100%; height: 700px;" alt="...">
                <div class="carousel-caption d-none d-md-block c-font">
                    <h1 class="display-4">Prateek Fitness</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Explicabo, provident.</p>
                </div>
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions"
            data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions"
            data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>
    <div style="background-color: gray;">
    <hr>
    <h2 style="text-align: center; color: goldenrod;">Register Now !!!</h2>
    <hr>
    </div>
    <div class="container form">
        <form class="row g-3" action="index.php" method="post">
            <div class="col-md-6">
              <label class="form-label">First Name</label>
              <input type="text" class="form-control" id="inputEmail4"  name="f_name">
            </div>
            <div class="col-md-6">
              <label class="form-label">Last Name</label>
              <input type="text" class="form-control" id="inputPassword4" name="l_name">
            </div>
            <div class="col-12">
              <label for="inputAddress" class="form-label">Address</label>
              <input type="text" class="form-control" id="inputAddress" placeholder="1234 Main St" name="address">
            </div>
            <div class="col-md-6">
              <label for="inputCity" class="form-label">City</label>
              <input type="text" class="form-control" id="inputCity" name="city" >
            </div>
            <div class="col-md-4">
              <label for="inputState" class="form-label">Pack</label>
              <select id="inputState" class="form-select" name="pack" >
                <option>Cardio</option>
                <option>Weight Lifting</option>
                <option>Cardio and Lifting Both</option>
              </select>
            </div>
            <div class="col-md-4">
                <label for="inputState" class="form-label">Batch</label>
                <select id="inputState" class="form-select" name="batch" >
                  <option>Morning(6am-9am)</option>
                  <option>Afternoon(2pm-5pm)</option>
                  <option>Evening(7pm-11pm)</option>
                </select>
              </div>
            <div class="col-12">
              <div class="form-check">
                <input class="form-check-input" type="checkbox" id="gridCheck">
                <label class="form-check-label" for="gridCheck">
                  I agree
                </label>
              </div>
            </div>
            <div class="col-12">
              <button type="submit" class="btn btn-primary" name="register">Register</button>
            </div>
          </form>
              
    </div>
    <hr style="color: aliceblue;">

    <footer class="container">
        <p class="float-end"><a href="#">Back to top</a></p>
        <p>© 2017–2021 Company, Inc. · <a href="#">Privacy</a> · <a href="#">Terms</a></p>
      </footer>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4"
        crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>
    -->
</body>

</html>