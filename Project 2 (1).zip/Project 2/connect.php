<?php
$con = mysqli_connect("localhost","root","","gym") or die ("error" . mysqli_error($con));
?>